package com.hitpixell.invoice.model;

public enum TransactionStatus {
    APPROVED,
    DECLINED,
    REFUNDED
}
