package com.hitpixell.invoice.model;

public enum BillingInterval {
    DAILY,
    MONTHLY
}
